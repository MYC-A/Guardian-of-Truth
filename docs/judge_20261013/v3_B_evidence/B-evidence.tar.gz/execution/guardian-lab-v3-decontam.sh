#!/bin/bash
set -euo pipefail
export PYTHONPATH=/workspace/guardian-lab-20261018/code/src
exec timeout --signal=TERM --kill-after=30 1800 /workspace/guardian-lab-20261018/venv/bin/python /workspace/guardian-lab-20261018/code/scripts/v3_decontaminate.py --draft /workspace/guardian-lab-20261018/v3-20261019/external-draft-v1/candidate_rows.jsonl --protected /workspace/guardian-lab-20261018/data/guardian-judge-eval-data-v1 --out /workspace/guardian-lab-20261018/v3-20261019/external-decontam-v1
