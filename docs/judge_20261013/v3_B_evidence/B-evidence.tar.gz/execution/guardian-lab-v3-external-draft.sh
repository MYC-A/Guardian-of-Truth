#!/bin/bash
set -euo pipefail
export PYTHONPATH=/workspace/guardian-lab-20261018/code/src
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
exec timeout --signal=TERM --kill-after=30 1800 /workspace/guardian-lab-20261018/venv/bin/python /workspace/guardian-lab-20261018/code/scripts/v3_normalize_external.py --root /workspace/guardian-lab-20261018/v3-20261019 --model /workspace/guardian-lab-20261018/models/qwen3-4b-instruct --out /workspace/guardian-lab-20261018/v3-20261019/external-draft-v1
