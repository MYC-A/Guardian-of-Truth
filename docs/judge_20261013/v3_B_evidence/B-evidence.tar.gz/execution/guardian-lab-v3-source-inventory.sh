#!/bin/bash
set -euo pipefail
exec timeout --signal=TERM --kill-after=30 1800 /workspace/guardian-lab-20261018/venv/bin/python /workspace/guardian-lab-20261018/code/scripts/v3_fetch_sources.py --out /workspace/guardian-lab-20261018/v3-20261019/source-inventory
