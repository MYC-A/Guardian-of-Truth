---
dataset_info:
  features:
  - name: id
    dtype: string
  - name: passage
    dtype: string
  - name: question
    dtype: string
  - name: answer
    dtype: string
  - name: label
    dtype: string
  - name: source_ds
    dtype: string
  splits:
  - name: test
    num_bytes: 30159779
    num_examples: 14900
  download_size: 7512526
  dataset_size: 30159779
configs:
- config_name: default
  data_files:
  - split: test
    path: data/test-*
license: cc-by-nc-2.0
task_categories:
- text-generation
language:
- en
tags:
- hallucination-evaluation
- benchmark
pretty_name: HaluBench
size_categories:
- 10K<n<100K
---

# Dataset Card for HaluBench

## Dataset Details
HaluBench is a hallucination evaluation benchmark of 15k samples that consists of Context-Question-Answer triplets annotated for whether the examples contain
hallucinations. Compared to prior datasets, HaluBench is the first open-source benchmark containing hallucination tasks sourced from
real-world domains that include finance and medicine.

We sourced examples from several existing QA datasets to build the hallucination evaluation benchmark. We constructed tuples of (question, context,
answer, label), where label is a binary score that denotes whether the answer contains a hallucination. 

The examples are sourced from and constructed using existing datasets such as FinanceBench, PubmedQA, CovidQA, HaluEval, DROP and RAGTruth.

- **Curated by:** Patronus AI
- **Language(s) (NLP):** English

## Use
HaluBench can be used to evaluate hallucination detection models. [The PatronusAI/Llama-3-Patronus-Lynx-70B-Instruct](https://huggingface.co/PatronusAI/Llama-3-Patronus-Lynx-70B-Instruct) outperforms GPT-4o, Claude-Sonnet and other open source models on HaluBench.
[PatronusAI/Llama-3-Patronus-Lynx-8B-Instruct](https://huggingface.co/PatronusAI/Llama-3-Patronus-Lynx-8B-Instruct)  is a 8B variant that has only a ~3% gap compared to GPT-4o.

## Dataset Card Contact

[@sunitha-ravi](https://huggingface.co/sunitha-ravi)