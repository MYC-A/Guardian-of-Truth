#!/bin/bash
set -euo pipefail
export PYTHONPATH=/workspace/guardian-lab-20261018/code/src
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
cd /workspace/guardian-lab-20261018/code
exec timeout --signal=TERM --kill-after=30 900 /workspace/guardian-lab-20261018/venv/bin/python scripts/eval_lora_tooltruth_style_20261018.py --model /workspace/guardian-lab-20261018/models/qwen3-4b-instruct --run /workspace/guardian-lab-20261018/lora-tooltruth-v2b-run --input /workspace/guardian-lab-20261018/style_probe_inputs.jsonl --out /workspace/guardian-lab-20261018/lora-tooltruth-v2b-style
