#!/bin/bash
set -euo pipefail
export PYTHONPATH=/workspace/guardian-lab-20261018/code/src
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false
cd /workspace/guardian-lab-20261018/code
exec timeout --signal=TERM --kill-after=30 5400 /workspace/guardian-lab-20261018/venv/bin/python scripts/train_lora_tooltruth_20261018.py --model /workspace/guardian-lab-20261018/models/qwen3-4b-instruct --data /workspace/guardian-lab-20261018/lora-tooltruth-v2b-data --real-input /workspace/guardian-lab-20261018/data/guardian-judge-eval-data-v1/regression_seen/inputs.csv --out /workspace/guardian-lab-20261018/lora-tooltruth-v2b-run
