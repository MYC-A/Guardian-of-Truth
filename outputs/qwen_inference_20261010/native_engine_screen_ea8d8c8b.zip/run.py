from pathlib import Path
import json, os, subprocess, time, traceback
BASE = Path(__file__).resolve().parent
CODE = BASE / 'code'
PYTHON = '/workspace/guardian/pilot_20261010/venv/bin/python'
env = dict(os.environ, PYTHONPATH=str(CODE / 'src') + ':' + str(CODE),
    PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1', LLAMA_ARG_THREADS='8',
    LLAMA_ARG_THREADS_BATCH='8', OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='1')
phases = [
    ('scaling', ['scripts/qwen_engine_scaling.py', '--root', '/workspace/guardian/runtime',
        '--output', str(BASE / 'scaling'), '--repetitions', '1']),
    ('reviewer', ['scripts/qwen_inference_bench.py', 'run', '--root', '/workspace/guardian/runtime',
        '--plan', 'outputs/qwen_inference_20261010/plan.json', '--output', str(BASE / 'reviewer'),
        '--arms', 'base', 'queue16', 'ngram', '--repetitions', '1'])]
ledger = []
try:
    for name, args in phases:
        started = time.monotonic()
        (BASE / 'ACTIVE_PHASE.json').write_text(json.dumps(dict(phase=name)), encoding='utf-8')
        command = ['/usr/bin/timeout', '--signal=TERM', '--kill-after=20', '1200', PYTHON, '-u', *args]
        with (BASE / (name + '.stdout.log')).open('x', encoding='utf-8') as out, \
             (BASE / (name + '.stderr.log')).open('x', encoding='utf-8') as err:
            result = subprocess.run(command, cwd=CODE, env=env, stdout=out, stderr=err)
        entry = dict(phase=name, returncode=result.returncode, whole_seconds=time.monotonic()-started)
        ledger.append(entry)
        (BASE / 'phase_ledger.json').write_text(json.dumps(ledger, indent=2), encoding='utf-8')
        if result.returncode:
            raise RuntimeError('PHASE_FAILED:' + name + ':' + str(result.returncode))
    (BASE / 'DONE.json').write_text(json.dumps(dict(status='COMPLETE', phases=ledger)), encoding='utf-8')
except BaseException:
    (BASE / 'FAILED.txt').write_text(traceback.format_exc(), encoding='utf-8')
    raise
