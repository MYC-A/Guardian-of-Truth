#!/bin/bash
set -u
cd /workspace/guardian/vllm_graph16_20261010/code
export PYTHONPATH=/workspace/guardian/vllm_graph16_20261010/code/src:/workspace/guardian/vllm_graph16_20261010/code PYTHONUTF8=1 PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=8 PYTHONNOUSERSITE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 VLLM_NO_USAGE_STATS=1 DO_NOT_TRACK=1
unset LD_LIBRARY_PATH LD_PRELOAD PYTHONHOME VIRTUAL_ENV
date +%s.%N > /workspace/guardian/vllm_graph16_20261010/start
/usr/bin/timeout --signal=TERM --kill-after=30 1860 /workspace/guardian/vllm_phase2_20261010/venv/bin/python -u scripts/qwen_vllm_adapter.py --python /workspace/guardian/vllm_phase2_20261010/venv/bin/python --model-dir /workspace/guardian/vllm_probe_20261010/017b9c7af6b5689d5dd426a76e0bc077eb5ca20a --asset-manifest /workspace/guardian/vllm_phase2_20261010/verified_asset_manifest.json --input /workspace/guardian/vllm_graph16_20261010/code/valid.parquet --slots 16 --context 32768 --startup-timeout 900 --output /workspace/guardian/vllm_graph16_20261010/valid46 --limit 46 --workers 16 --timeout 600 --duration 1800 --max-calls 400 > /workspace/guardian/vllm_graph16_20261010/adapter.stdout.log 2> /workspace/guardian/vllm_graph16_20261010/adapter.stderr.log
echo $? > /workspace/guardian/vllm_graph16_20261010/rc
date +%s.%N > /workspace/guardian/vllm_graph16_20261010/end
