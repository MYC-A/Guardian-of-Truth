from pathlib import Path
import json, os, subprocess, time, traceback
ROOT=Path(__file__).resolve().parent
started=time.monotonic()
env=dict(os.environ,HF_HOME=str(ROOT/'hf_state'),HF_XET_HIGH_PERFORMANCE='1',
    HF_XET_NUM_CONCURRENT_RANGE_GETS='8',HF_XET_CHUNK_CACHE_SIZE_BYTES='0',
    HF_HUB_ETAG_TIMEOUT='30',HF_HUB_DOWNLOAD_TIMEOUT='60',UV_HTTP_TIMEOUT='120',
    UV_CONCURRENT_DOWNLOADS='8',UV_CONCURRENT_INSTALLS='4',PYTHONUTF8='1')
try:
    for name in ('venv','download_venv'):
        subprocess.run(['uv','venv','--python','/usr/bin/python3',str(ROOT/name)],check=True,timeout=60)
    subprocess.run(['uv','pip','install','--python',str(ROOT/'download_venv/bin/python'),
        '--no-cache','huggingface-hub==2.2.0'],env=env,check=True,timeout=180)
    logs=[]
    jobs=[]
    commands=[('install',['uv','pip','install','--python',str(ROOT/'venv/bin/python'),
        '--no-cache','vllm==0.19.1','transformers==5.5.4','pandas','pyarrow','pytest']),
        ('download',[str(ROOT/'download_venv/bin/python'),'-u',str(ROOT/'download.py')])]
    for name,command in commands:
        log=(ROOT/(name+'.log')).open('x',encoding='utf-8')
        logs.append(log)
        jobs.append((name,subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)))
    ledger=[]
    for name,process in jobs:
        rc=process.wait()
        ledger.append(dict(phase=name,returncode=rc,observed_elapsed_seconds=time.monotonic()-started))
        (ROOT/'SETUP_LEDGER.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
    for log in logs:
        log.close()
    if any(item['returncode'] for item in ledger):
        raise RuntimeError('SETUP_PHASE_FAILED')
    freeze=subprocess.check_output(['uv','pip','freeze','--python',str(ROOT/'venv/bin/python')],env=env,text=True)
    (ROOT/'requirements-frozen.txt').write_text(freeze,encoding='utf-8')
    subprocess.run([str(ROOT/'venv/bin/python'),'-c',
        'import vllm,torch,transformers; print(vllm.__version__,torch.__version__,transformers.__version__)'],
        env=env,check=True,timeout=60)
    (ROOT/'SETUP_DONE.json').write_text(json.dumps(dict(status='COMPLETE',seconds=time.monotonic()-started,
        vllm='0.19.1',transformers='5.5.4',repo='Qwen/Qwen3.8-27B-FP8',
        revision='017b9c7af6b5689d5dd426a76e0bc077eb5ca20a',gpu_started=False)),encoding='utf-8')
except BaseException:
    (ROOT/'SETUP_FAILED.txt').write_text(traceback.format_exc(),encoding='utf-8')
    raise
