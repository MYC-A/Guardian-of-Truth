import hashlib, json, os, time, urllib.request
from pathlib import Path
from huggingface_hub import snapshot_download
ROOT=Path(__file__).resolve().parent
REPO='Qwen/Qwen3.8-27B-FP8'
REV='017b9c7af6b5689d5dd426a76e0bc077eb5ca20a'
started=time.monotonic()
def get(url):
    with urllib.request.urlopen(url,timeout=30) as response:
        return json.load(response)
meta=get('https://huggingface.co/api/models/'+REPO+'/revision/'+REV+'?blobs=true')
assert meta['sha']==REV
index=get('https://huggingface.co/'+REPO+'/resolve/'+REV+'/model.safetensors.index.json')
weights=set(index['weight_map'].values())
files={x['rfilename']:x for x in meta['siblings']}
assert len(weights)==66 and sum(files[n]['size'] for n in weights)==30866866928
extras={'config.json','generation_config.json','model.safetensors.index.json','chat_template.jinja',
        'tokenizer.json','tokenizer_config.json','vocab.json','merges.txt','added_tokens.json',
        'special_tokens_map.json','preprocessor_config.json','processor_config.json','LICENSE','README.md'}
selected=sorted(weights | (extras & set(files)))
(ROOT/'DOWNLOAD_PROTOCOL.json').write_text(json.dumps(dict(repo=REPO,revision=REV,
    max_workers=8,weight_bytes=30866866928,files=selected,source='Direct HuggingFace to server'),indent=2),encoding='utf-8')
target=ROOT/'model'
snapshot_download(REPO,revision=REV,local_dir=target,allow_patterns=selected,max_workers=8)
manifest={}
for name in selected:
    path=target/name
    assert path.stat().st_size==files[name]['size'],name
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(16*1024*1024),b''):
            h.update(chunk)
    actual=h.hexdigest()
    expected=(files[name].get('lfs') or {}).get('sha256')
    if expected:
        assert actual==expected,name
    manifest[name]=dict(bytes=path.stat().st_size,sha256=actual,hub_lfs_sha256=expected)
(ROOT/'model_manifest.json').write_text(json.dumps(dict(repo=REPO,revision=REV,files=manifest),indent=2),encoding='utf-8')
(ROOT/'DOWNLOAD_DONE.json').write_text(json.dumps(dict(status='COMPLETE',seconds=time.monotonic()-started,
    total_bytes=sum(v['bytes'] for v in manifest.values()),files=len(manifest))),encoding='utf-8')
