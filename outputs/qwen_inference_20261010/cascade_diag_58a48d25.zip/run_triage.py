import hashlib, json, os, pathlib, sys, threading, time, traceback
ROOT = pathlib.Path(__file__).resolve().parent
CODE = ROOT / 'code'
sys.path[:0] = [str(CODE / 'src'), str(CODE)]
os.environ.update(PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1', LLAMA_ARG_THREADS='8',
                  LLAMA_ARG_THREADS_BATCH='8', OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='1')
from guardian_truth.cascade import cli
from guardian_truth.cascade.backend import TriageClient
from guardian_truth.integrated.transport import sha
lock, context = threading.Lock(), threading.local()
original_row, original_complete = cli.triage_row, TriageClient.complete
def row(client, value, *args):
    context.identifier = value['id']
    return original_row(client, value, *args)
def complete(self, request, tag=''):
    data, record = original_complete(self, request, tag)
    raw = dict(id=context.identifier, tag=tag, request_sha256=sha(request), request=request,
               response=data, transport_record=dict(record))
    with lock:
        with (ROOT / 'raw_triage.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(raw, ensure_ascii=False) + '\n')
            stream.flush()
    return data, record
cli.triage_row, TriageClient.complete = row, complete
(ROOT / 'STARTED.json').write_text(json.dumps(dict(source_sha='58a48d25334aff0b737f4d62a7c21dc6cf927d75',
    scope='Frozen branch triage-only diagnostic, approximate scores; NOT deployment or calibrated probabilities',
    raw_capture_wrapper=True, max_source_attempts=184, outer_timeout_seconds=900,
    source_method='Direct GitHub sparse clone, exact HEAD checked')),
    encoding='utf-8')
try:
    cli.main(['--mode','triage-only','--input',str(CODE / 'valid.parquet'),
        '--output',str(ROOT / 'predictions.parquet'),'--work-dir',str(ROOT / 'run'),
        '--root','/workspace/guardian/runtime','--workers','8','--slots','8','--deadline','840'])
    import pandas as pd
    truth = pd.read_parquet(CODE / 'valid.parquet').set_index('id')['label']
    pred = pd.read_parquet(ROOT / 'predictions.parquet').set_index('id')['label']
    assert len(pred) == len(truth) == 46 and set(pred.index) == set(truth.index)
    counts = {key:0 for key in ('TP','FP','FN','TN')}
    for identifier, label in truth.items():
        counts[('TN','FP','FN','TP')[2*int(label)+int(pred[identifier])]] += 1
    counts['F1'] = 2*counts['TP']/(2*counts['TP']+counts['FP']+counts['FN'])
    (ROOT / 'diagnostic_score.json').write_text(json.dumps(dict(metrics=counts,
        scope='Frozen one-token triage only at default threshold0.5, not B2 or tuned cascade'),indent=2),encoding='utf-8')
    (ROOT / 'DONE.json').write_text(json.dumps(dict(status='COMPLETE', metrics=counts)),encoding='utf-8')
except BaseException:
    (ROOT / 'FAILED.txt').write_text(traceback.format_exc(), encoding='utf-8')
    raise
